# Guardiões da Vida — site do TCC

Site estático de uma página. O arquivo principal é `index.html`.

## Publicar no GitHub Pages
1. Crie um repositório público chamado `guardioes-da-vida`.
2. Envie `index.html` para a raiz do repositório (Add file > Upload files).
3. Abra Settings > Pages.
4. Em Build and deployment, escolha Deploy from a branch.
5. Escolha `main` e `/ (root)`, depois Save.
6. Aguarde alguns minutos. O endereço ficará parecido com:
   https://SEU-USUARIO.github.io/guardioes-da-vida/

Este é um projeto acadêmico independente, sem vínculo institucional com Médicos Sem Fronteiras.
